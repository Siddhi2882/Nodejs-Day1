console.log("hello nikiii");
//console.log(document);

var xmlhttp = new XMLHttpRequest();
console.log(xmlhttp);



npm init -y
//mongodb

//to create new database
user userdetails

//to see databases
show dbs

//to see current database
db

//to create collections
 db.createCollection("users")

//to see collections
 show collections

//3 ways to insert the details
 insert()
 insertOne()
 insertMany()

//insert data
 db.users.insert([{"name": "Siddhi", "age":22,"place": "shd"},
 {"name": "Nikita", "age":22,"place": "pune"},
 {"name": "anvita", "age":23,"place": "mumbai"}]);

//select query
 db.users.find();

 //to find specif detail from the inserted one
 db.users.find({"place":"pune"})

 //remove
 db.users.remove({"place":"pune"})

//update has 2
//1st is operation and 2nd is set
 db.users.update({"place":"mumbai"},{$set:{"name":"niki","age":22}})

 //mysql
 var mysql      = require('mysql');
var connection = mysql.createConnection({
  host     : 'localhost',
  user     : 'me',
  password : 'secret',
  database : 'my_db'
});